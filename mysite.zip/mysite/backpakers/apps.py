from django.apps import AppConfig


class BackpakersConfig(AppConfig):
    name = 'backpakers'
